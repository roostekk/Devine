export const environment = {
  apiUrl: 'https://deezerdevs-deezer.p.rapidapi.com/',
  apiKey: 'd93083a991mshbf6fe892af90675p19b19fjsn54d1c9fb710d',
  production: true
};
